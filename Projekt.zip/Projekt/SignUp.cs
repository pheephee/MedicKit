﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtSignUpUsername.Text;
            string email = txtSignUpEmail.Text;
            string password = txtSignUpPassword.Text;
            string confpassword = txtSignUpConfPassword.Text;
            List<string> listaKorisnika = new List<string>();
            if(listaKorisnika.Contains(username))
            {
                MessageBox.Show("Korisničko ime je zauzteto!");
            }
            else
            {
                if (listaKorisnika.Contains(email))
                {
                    MessageBox.Show("email koji ste unijeli se već koristi!");
                }
                else if (email.Contains("@") && email.Contains("."))
                {
                    if (password != confpassword)
                    {
                        MessageBox.Show("Lozinke se moraju podudarati!");
                    }
                    else
                    {
                        listaKorisnika.Add(username + email + password);
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Oblik unesenog emaila nije dobar!");
                }
            }

        }
    }
}
