﻿namespace Projekt
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.uiNapraviIzvjestaj = new System.Windows.Forms.Button();
            this.uiNapraviNarudzbenicu = new System.Windows.Forms.Button();
            this.uiNapraviRacun = new System.Windows.Forms.Button();
            this.uiUpitUStanjeSkladista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // uiNapraviIzvjestaj
            // 
            this.uiNapraviIzvjestaj.BackColor = System.Drawing.Color.CornflowerBlue;
            this.uiNapraviIzvjestaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.uiNapraviIzvjestaj.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.uiNapraviIzvjestaj.Location = new System.Drawing.Point(115, 310);
            this.uiNapraviIzvjestaj.Name = "uiNapraviIzvjestaj";
            this.uiNapraviIzvjestaj.Size = new System.Drawing.Size(253, 67);
            this.uiNapraviIzvjestaj.TabIndex = 5;
            this.uiNapraviIzvjestaj.Text = "Izvještaj";
            this.uiNapraviIzvjestaj.UseVisualStyleBackColor = false;
            // 
            // uiNapraviNarudzbenicu
            // 
            this.uiNapraviNarudzbenicu.BackColor = System.Drawing.Color.CornflowerBlue;
            this.uiNapraviNarudzbenicu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.uiNapraviNarudzbenicu.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.uiNapraviNarudzbenicu.Location = new System.Drawing.Point(115, 164);
            this.uiNapraviNarudzbenicu.Name = "uiNapraviNarudzbenicu";
            this.uiNapraviNarudzbenicu.Size = new System.Drawing.Size(253, 67);
            this.uiNapraviNarudzbenicu.TabIndex = 6;
            this.uiNapraviNarudzbenicu.Text = "Narudžbenica";
            this.uiNapraviNarudzbenicu.UseVisualStyleBackColor = false;
            // 
            // uiNapraviRacun
            // 
            this.uiNapraviRacun.BackColor = System.Drawing.Color.CornflowerBlue;
            this.uiNapraviRacun.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.uiNapraviRacun.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.uiNapraviRacun.Location = new System.Drawing.Point(115, 91);
            this.uiNapraviRacun.Name = "uiNapraviRacun";
            this.uiNapraviRacun.Size = new System.Drawing.Size(253, 67);
            this.uiNapraviRacun.TabIndex = 7;
            this.uiNapraviRacun.Text = "Račun";
            this.uiNapraviRacun.UseVisualStyleBackColor = false;
            // 
            // uiUpitUStanjeSkladista
            // 
            this.uiUpitUStanjeSkladista.BackColor = System.Drawing.Color.CornflowerBlue;
            this.uiUpitUStanjeSkladista.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.uiUpitUStanjeSkladista.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.uiUpitUStanjeSkladista.Location = new System.Drawing.Point(115, 237);
            this.uiUpitUStanjeSkladista.Name = "uiUpitUStanjeSkladista";
            this.uiUpitUStanjeSkladista.Size = new System.Drawing.Size(253, 67);
            this.uiUpitUStanjeSkladista.TabIndex = 9;
            this.uiUpitUStanjeSkladista.Text = "Skladište";
            this.uiUpitUStanjeSkladista.UseVisualStyleBackColor = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(495, 464);
            this.Controls.Add(this.uiUpitUStanjeSkladista);
            this.Controls.Add(this.uiNapraviRacun);
            this.Controls.Add(this.uiNapraviNarudzbenicu);
            this.Controls.Add(this.uiNapraviIzvjestaj);
            this.Name = "Main";
            this.Text = "Main";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button uiNapraviIzvjestaj;
        private System.Windows.Forms.Button uiNapraviNarudzbenicu;
        private System.Windows.Forms.Button uiNapraviRacun;
        private System.Windows.Forms.Button uiUpitUStanjeSkladista;
    }
}